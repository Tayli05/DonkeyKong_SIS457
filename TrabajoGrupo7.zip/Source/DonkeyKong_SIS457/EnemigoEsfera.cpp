// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoEsfera.h"

AEnemigoEsfera::AEnemigoEsfera()
{
}

void AEnemigoEsfera::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

