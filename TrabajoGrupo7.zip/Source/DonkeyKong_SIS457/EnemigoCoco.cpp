// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoCoco.h"

AEnemigoCoco::AEnemigoCoco()
{

}

void AEnemigoCoco::Tick(float DeltaTime)
{
		Super::Tick(DeltaTime);
}

void AEnemigoCoco::MoverEnemigo(float DeltaTime)
{
}

void AEnemigoCoco::CambiarDireccion()
{
}

void AEnemigoCoco::Atacar()
{
}

void AEnemigoCoco::Desaparecer()
{
}
