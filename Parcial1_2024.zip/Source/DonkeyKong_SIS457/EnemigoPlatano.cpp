// Fill out your copyright notice in the Description page of Project Settings.


#include "EnemigoPlatano.h"

AEnemigoPlatano::AEnemigoPlatano()
{
}

void AEnemigoPlatano::Tick(float DeltaTime)
{
		Super::Tick(DeltaTime);
}
